<div class="py-5 text-center" style="background-image: url('img/music-banner-5531b6e1cd739730ad8bc5e7fe5d6a6f.jpg');">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-12">
                <h1 class="display-3 mb-4 text-warning">Welkom bij SpotiTube</h1>
                <p class="lead mb-5 text-light">Maak je eigen playlist, voeg je filmpjes toe, of bekijk anderen hun filmpjes.&nbsp;
                    <br>
                    <br>Deel je filmpjes met de wereld.</p>
                <a href="#" class="btn btn-lg mx-1 btn-secondary">Bekijk playlists</a>
                <a href="#" class="btn btn-lg btn-primary mx-1">Aanmelden</a>
            </div>
        </div>
    </div>
</div>